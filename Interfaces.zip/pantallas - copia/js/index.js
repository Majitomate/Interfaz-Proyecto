document.getElementById("notificaciones-dropdown-btn").addEventListener("click", function(event) {
    event.preventDefault();
    let dropdown = document.querySelector(".dropdown");
    dropdown.classList.toggle("active");
});

// se cierra el dropdown si se da click fuera
window.addEventListener("click", function(event) {
    let dropdown = document.querySelector(".dropdown");
    if (!dropdown.contains(event.target)) {
        dropdown.classList.remove("active");
    }
});
