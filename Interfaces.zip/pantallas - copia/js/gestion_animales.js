document.addEventListener("DOMContentLoaded", () => {
    const addAnimalBtn = document.getElementById("addAnimal");
    const searchAnimalBtn = document.getElementById("searchAnimal");
    const animalCardsContainer = document.querySelector(".animal-cards");
    const searchInput = document.getElementById("search");


    // se abre modal para registrar un animal
    addAnimalBtn.addEventListener("click", () => {
        const modal = document.createElement("div");
        modal.classList.add("modal");
        modal.innerHTML = `
            <div class="modal-content">
                <h2>Agregar Animal</h2>
                <label>Identificador:</label>
                <input type="text" id="animalId" required>
                <label>Raza:</label>
                <input type="text" id="animalBreed" required>
                <label>Edad:</label>
                <input type="number" id="animalAge" min="0" required>
                <label>Peso:</label>
                <input type="number" id="animalWeight" min="0" required>
                <label>Género:</label>
                <select id="animalGender">
                    <option value="Macho">Macho</option>
                    <option value="Hembra">Hembra</option>
                </select>
                <label>Estado de Salud:</label>
                <select id="salud">
                    <option value="Saludable">Saludable</option>
                    <option value="Enfermo">Enfermo</option>
                </select>
                <button id="saveAnimal">Guardar</button>
                <button id="closeModal">Cancelar</button>
            </div>
        `;
        document.body.appendChild(modal);

        // cerrar modal
        document.getElementById("closeModal").addEventListener("click", () => {
            modal.remove();
        });

        // Guardar animal
        document.getElementById("saveAnimal").addEventListener("click", () => {
            const id = document.getElementById("animalId").value;
            const breed = document.getElementById("animalBreed").value;
            const age = document.getElementById("animalAge").value;
            const weight = document.getElementById("animalWeight").value;
            const gender = document.getElementById("animalGender").value;
            const salud = document.getElementById("salud").value;

            if (id && breed && age && weight && gender && salud) {
                addAnimalCard(id, breed, age, weight, gender, salud);
                animals.push({ id, breed, age, weight, gender, salud });
                localStorage.setItem("animals", JSON.stringify(animals));
                modal.remove();
            } else {
                alert("Por favor, completa todos los campos.");
            }
        });
    });



    // Función para agregar tarjeta de animal
    function addAnimalCard(id, breed, age, weight, gender, salud) {
        const card = document.createElement("div");
        card.classList.add("animal-card");
        card.innerHTML = `
            <h3>ID: ${id}</h3>
            <p>Raza: ${breed}</p>
            <p>Edad: ${age} años</p>
            <p>Peso: ${weight} kg</p>
            <p>Género: ${gender}</p>
            <p>Estado de Salud: ${salud}</p>
            <button class="delete-btn" data-id="${id}">Eliminar</button>
        `;
        animalCardsContainer.appendChild(card);
    }
});