document.addEventListener("DOMContentLoaded", () => {
    const modal = document.getElementById("modal");
    const openModal = document.getElementById("openModal");
    const closeModal = document.getElementById("closeModal");
    const form = document.getElementById("control-form");
    const tableBody = document.querySelector("tbody");

    openModal.addEventListener("click", () => {
        modal.style.display = "flex";
    });

    closeModal.addEventListener("click", () => {
        modal.style.display = "none";
    });

    form.addEventListener("submit", (event) => {
        event.preventDefault();
        
        const tipo = document.getElementById("tipo").value;
        const fecha = document.getElementById("fecha").value;
        const descripcion = document.getElementById("descripcion").value;
        
        const newRow = document.createElement("tr");
        newRow.innerHTML = `
            <td>${tableBody.children.length + 1}</td>
            <td>${tipo}</td>
            <td>${fecha}</td>
            <td>${descripcion}</td>
            <td>
                <button class="edit"><i class="fas fa-edit"></i></button>
                <button class="delete"><i class="fas fa-trash"></i></button>
            </td>
        `;
        tableBody.appendChild(newRow);
        
        modal.style.display = "none";
        form.reset();
    });

    tableBody.addEventListener("click", (event) => {
        if (event.target.closest(".delete")) {
            let acepta = confirm("Estas seguro de eliminar el registro?")
            if(acepta){
                event.target.closest("tr").remove();
            }
            
        }
    });
});
