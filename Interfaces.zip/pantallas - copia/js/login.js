document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();
    
        // efectito
        document.querySelector(".btn").textContent = "Cargando...";
        setTimeout(() => {
            window.location.href = "index.html";
        }, 1500);

});
