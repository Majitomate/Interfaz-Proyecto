document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();
    
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const errorMessage = document.getElementById("errorMessage");

    if (username === "admin" && password === "1234") {
        // efectito
        document.querySelector(".btn").textContent = "Cargando...";
        setTimeout(() => {
            window.location.href = "index.html";
        }, 1500);
    } else {
        errorMessage.textContent = "Usuario o contraseña incorrectos";
        errorMessage.style.display = "block";
    }
});
