document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("config-form");

    form.addEventListener("submit", function (event) {
        event.preventDefault();
        
        const nombre = document.getElementById("nombre").value;
        const password = document.getElementById("password").value;
        const notificaciones = document.getElementById("notificaciones").checked;
        
        if (nombre === "" || password === "") {
            alert("Por favor, completa todos los campos");
            return;
        }
        
        const configuracion = {
            nombre,
            password,
            notificaciones
        };
        
        localStorage.setItem("configuracionAdmin", JSON.stringify(configuracion));
        alert("Configuración guardada exitosamente.");
    });

    function cargarConfiguracion() {
        const configGuardada = localStorage.getItem("configuracionAdmin");
        if (configGuardada) {
            const config = JSON.parse(configGuardada);
            document.getElementById("nombre").value = config.nombre;
            document.getElementById("password").value = config.password;
            document.getElementById("notificaciones").checked = config.notificaciones;
        }
    }

    cargarConfiguracion();
});
