document.addEventListener("DOMContentLoaded", () => {
    const addAnimalBtn = document.getElementById("addAnimal");
    const searchAnimalBtn = document.getElementById("searchAnimal");
    const animalCardsContainer = document.querySelector(".animal-cards");
    const searchInput = document.getElementById("search");

    // Cargar animales desde localStorage
    const animals = JSON.parse(localStorage.getItem("animals")) || [];
    animals.forEach(animal => {
        addAnimalCard(animal.id, animal.breed, animal.age, animal.weight, animal.gender, animal.salud);
    });

    // Agregar animal
    addAnimalBtn.addEventListener("click", () => {
        const modal = document.createElement("div");
        modal.classList.add("modal");
        modal.innerHTML = `
            <div class="modal-content">
                <h2>Agregar Animal</h2>
                <label>Identificador:</label>
                <input type="text" id="animalId" required>
                <label>Raza:</label>
                <input type="text" id="animalBreed" required>
                <label>Edad:</label>
                <input type="number" id="animalAge" min="0" required>
                <label>Peso:</label>
                <input type="number" id="animalWeight" min="0" required>
                <label>Género:</label>
                <select id="animalGender">
                    <option value="Macho">Macho</option>
                    <option value="Hembra">Hembra</option>
                </select>
                <label>Estado de Salud:</label>
                <select id="salud">
                    <option value="Saludable">Saludable</option>
                    <option value="Enfermo">Enfermo</option>
                </select>
                <button id="saveAnimal">Guardar</button>
                <button id="closeModal">Cancelar</button>
            </div>
        `;
        document.body.appendChild(modal);

        // Cerrar modal
        document.getElementById("closeModal").addEventListener("click", () => {
            modal.remove();
        });

        // Guardar animal
        document.getElementById("saveAnimal").addEventListener("click", () => {
            const id = document.getElementById("animalId").value;
            const breed = document.getElementById("animalBreed").value;
            const age = document.getElementById("animalAge").value;
            const weight = document.getElementById("animalWeight").value;
            const gender = document.getElementById("animalGender").value;
            const salud = document.getElementById("salud").value;

            if (id && breed && age && weight && gender && salud) {
                addAnimalCard(id, breed, age, weight, gender, salud);
                animals.push({ id, breed, age, weight, gender, salud });
                localStorage.setItem("animals", JSON.stringify(animals));
                modal.remove();
            } else {
                alert("Por favor, completa todos los campos.");
            }
        });
    });

    // Buscar animal (modal de búsqueda)
    searchAnimalBtn.addEventListener("click", () => {
        const searchModal = document.createElement("div");
        searchModal.classList.add("modal");
        searchModal.innerHTML = `
            <div class="modal-content">
                <h2>Buscar Animal</h2>
                <label>Raza:</label>
                <input type="text" id="searchBreed">
                <label>Género:</label>
                <select id="searchGender">
                    <option value="">Todos</option>
                    <option value="Macho">Macho</option>
                    <option value="Hembra">Hembra</option>
                </select>
                <label>Estado de Salud:</label>
                <select id="searchSalud">
                    <option value="">Todos</option>
                    <option value="Saludable">Saludable</option>
                    <option value="Enfermo">Enfermo</option>
                </select>
                <button id="applySearch">Aplicar Filtros</button>
                <button id="closeSearchModal">Cancelar</button>
            </div>
        `;
        document.body.appendChild(searchModal);

        // Cerrar modal de búsqueda
        document.getElementById("closeSearchModal").addEventListener("click", () => {
            searchModal.remove();
        });

        // Aplicar filtros
        document.getElementById("applySearch").addEventListener("click", () => {
            const searchBreed = document.getElementById("searchBreed").value.toLowerCase();
            const searchGender = document.getElementById("searchGender").value;
            const searchSalud = document.getElementById("searchSalud").value;

            const cards = document.querySelectorAll(".animal-card");
            cards.forEach(card => {
                const breed = card.querySelector("p:nth-child(1)").textContent.toLowerCase();
                const gender = card.querySelector("p:nth-child(2)").textContent.replace("Género: ", "");
                const salud = card.querySelector("p:nth-child(3)").textContent.replace("Estado de Salud: ", "");

                const matchesBreed = breed.includes(searchBreed);
                const matchesGender = searchGender ? gender === searchGender : true;
                const matchesSalud = searchSalud ? salud === searchSalud : true;

                if (matchesBreed ||  matchesGender || matchesSalud) {
                    card.style.display = "block";
                } else {
                    card.style.display = "none";
                }
            });

            searchModal.remove();
        });
    });

    // Función para agregar tarjeta de animal
    function addAnimalCard(id, breed, age, weight, gender, salud) {
        const card = document.createElement("div");
        card.classList.add("animal-card");
        card.innerHTML = `
            <h3>ID: ${id}</h3>
            <p>Raza: ${breed}</p>
            <p>Edad: ${age} años</p>
            <p>Peso: ${weight} kg</p>
            <p>Género: ${gender}</p>
            <p>Estado de Salud: ${salud}</p>
            <button class="delete-btn" data-id="${id}">Eliminar</button>
        `;
        animalCardsContainer.appendChild(card);

        // Eliminar animal
        card.querySelector(".delete-btn").addEventListener("click", () => {
            let acepta = confirm("Deseas eliminar este animal?");

            if(acepta){
                card.remove();
                const index = animals.findIndex(animal => animal.id === id);
                if (index !== -1) {
                    animals.splice(index, 1);
                    localStorage.setItem("animals", JSON.stringify(animals));
                }
            }

        });
    }
});