document.addEventListener("DOMContentLoaded", () => {
    const modal = document.getElementById("modal");
    const openModal = document.getElementById("openModal");
    const closeModal = document.getElementById("closeModal");
    const form = document.getElementById("control-form");
    const tableBody = document.querySelector("tbody");
    const errorMessage = document.getElementById("errorMessage");

    openModal.addEventListener("click", () => {
        modal.style.display = "flex";
    });

    closeModal.addEventListener("click", () => {
        modal.style.display = "none";
    });

    form.addEventListener("submit", (event) => {
        event.preventDefault();
        
        const tipo = document.getElementById("tipo").value.trim();
        const fecha = document.getElementById("fecha").value.trim();
        const descripcion = document.getElementById("descripcion").value.trim();

        // validar campos vacíos
        if (!tipo || !fecha || !descripcion) {
            errorMessage.textContent = "Por favor, completa todos los campos.";
            errorMessage.style.display = "block";
            return;
        }

        // validar longitud mínima
        const MIN_DESC_LENGTH = 10;
        if (descripcion.length < MIN_DESC_LENGTH) {
            errorMessage.textContent = `La descripción debe tener al menos ${MIN_DESC_LENGTH} caracteres.`;
            errorMessage.style.display = "block";
            return;
        }

        // validar caracteres permitidos
        const textRegex = /^[a-zA-Z0-9\s]+$/;
        if (!textRegex.test(tipo) || !textRegex.test(descripcion)) {
            errorMessage.textContent = "Los campos de Tipo y Descripción solo pueden contener letras, números y espacios.";
            errorMessage.style.display = "block";
            return;
        }

        const newRow = document.createElement("tr");
        newRow.innerHTML = `
            <td>${tableBody.children.length + 1}</td>
            <td>${tipo}</td>
            <td>${fecha}</td>
            <td>${descripcion}</td>
            <td>
                <button class="edit"><i class="fas fa-edit"></i></button>
                <button class="delete"><i class="fas fa-trash"></i></button>
            </td>
        `;
        tableBody.appendChild(newRow);
        
        modal.style.display = "none";
        form.reset();
    });

    tableBody.addEventListener("click", (event) => {
        if (event.target.closest(".delete")) {
            let acepta = confirm("¿Estás seguro de eliminar el registro?");
            if (acepta) {
                event.target.closest("tr").remove();
            }
        }
    });
});
