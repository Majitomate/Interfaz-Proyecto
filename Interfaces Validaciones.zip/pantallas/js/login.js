document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();
    
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const errorMessage = document.getElementById("errorMessage");

    //validar tamaño de contraseña
    if (password.length < 8 || password.length > 16) {
        errorMessage.textContent = "La contraseña debe tener entre 8 y 16 caracteres.";
        errorMessage.style.display = "block";
    } else if (username === "admin" && password === "12345678"){
            // efectito
            document.querySelector(".btn").textContent = "Cargando...";
            setTimeout(() => {
                window.location.href = "index.html";
            }, 1500);
        } else {
            errorMessage.textContent = "Usuario o contraseña incorrectos";
            errorMessage.style.display = "block";
        }

});


