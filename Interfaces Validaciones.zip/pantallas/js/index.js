document.getElementById("notificaciones-dropdown-btn").addEventListener("click", function(event) {
    event.preventDefault();
    let dropdown = document.querySelector(".dropdown");
    dropdown.classList.toggle("active");
});

// Cerrar el dropdown si se hace clic fuera
window.addEventListener("click", function(event) {
    let dropdown = document.querySelector(".dropdown");
    if (!dropdown.contains(event.target)) {
        dropdown.classList.remove("active");
    }
});

